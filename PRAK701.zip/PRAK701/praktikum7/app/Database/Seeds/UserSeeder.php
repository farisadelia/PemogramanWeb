<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $this->db->table('user')->insert([
            'username' => 'syauqi',
            'email' => 'syauqialfath17@gmail.com',
            'password' => password_hash('1sampai8', PASSWORD_DEFAULT),
        ]);
    }
}
